KLLogRate_v1 supplementary material

Contents

- kl_pac_probe.py: stable inversion of the binary-KL event map and a dense
  evaluation of the localized complexity envelope.
- verify_kl_geometry.py: randomized checks of the inverse-scale bounds,
  convexity, localized spacing, complexity envelope, and endpoint-uniform
  Cressie--Read inequality.
- make_figure.py: regenerates kl_phase.pdf using exact scalar bisection.
- verification_output.txt: expected output from verify_kl_geometry.py.

Requirements

Python 3 with numpy, scipy, and matplotlib.

Quick checks

    python verify_kl_geometry.py
    python kl_pac_probe.py
    python make_figure.py

All computations are deterministic at the recorded random seed.  The paper's
theorems do not use the numerical checks.
