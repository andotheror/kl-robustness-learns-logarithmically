import math

import numpy as np
from scipy.optimize import brentq

from kl_pac_probe import inverse_nominal


def run(seed: int = 20260806, trials: int = 80, q_points: int = 240):
    rng = np.random.default_rng(seed)
    min_inverse_lower_ratio = float("inf")
    max_inverse_upper_ratio = 0.0
    min_spacing_ratio = float("inf")
    max_complexity_ratio = 0.0
    min_convex_slope_gap = float("inf")

    for _ in range(trials):
        eps = math.exp(rng.uniform(math.log(1e-4), math.log(0.25)))
        radius_ratio = math.exp(rng.uniform(math.log(1e-3), math.log(20.0)))
        rho = eps * radius_ratio
        b = inverse_nominal(eps, rho)

        lower = math.exp(-1.0) * eps * math.exp(-rho / eps)
        upper = eps * math.exp(-rho / eps)
        min_inverse_lower_ratio = min(min_inverse_lower_ratio, b / lower)
        max_inverse_upper_ratio = max(max_inverse_upper_ratio, b / upper)

        a = min(eps * eps, b)
        baseline = 1.0 / a
        qs = np.linspace(0.0, 1.0 - eps, q_points)
        vals = np.array([inverse_nominal(float(q), rho) for q in qs])
        vals_next = np.array([inverse_nominal(float(q + eps), rho) for q in qs])
        gaps = vals_next - vals

        spacing = gaps / (a + np.sqrt(a * vals))
        min_spacing_ratio = min(min_spacing_ratio, float(np.min(spacing)))

        complexity = vals / gaps**2 + 1.0 / gaps
        max_complexity_ratio = max(max_complexity_ratio,
                                   float(np.max(complexity / baseline)))

        # Convexity on an equally spaced q grid means successive slopes are nondecreasing.
        slopes = np.diff(vals) / np.diff(qs)
        min_convex_slope_gap = min(min_convex_slope_gap, float(np.min(np.diff(slopes))))

    print(f"trials={trials}, q_points={q_points}, seed={seed}")
    print(f"minimum b/(e^-1 eps e^(-rho/eps)): {min_inverse_lower_ratio:.9f}")
    print(f"maximum b/(eps e^(-rho/eps)): {max_inverse_upper_ratio:.9f}")
    print(f"minimum normalized spacing: {min_spacing_ratio:.9f}")
    print(f"maximum localized-complexity ratio: {max_complexity_ratio:.9f}")
    print(f"minimum discrete convex-slope gap: {min_convex_slope_gap:.3e}")

    assert min_inverse_lower_ratio >= 1.0 - 1e-10
    assert max_inverse_upper_ratio <= 1.0 + 1e-10
    assert min_spacing_ratio > 0.5
    assert max_complexity_ratio < 2.0
    assert min_convex_slope_gap > -1e-8

    min_cr_lower_ratio = float("inf")
    max_cr_upper_ratio = 0.0
    for _ in range(500):
        q = math.exp(rng.uniform(math.log(1e-4), math.log(0.7)))
        s = math.exp(rng.uniform(math.log(1e-3), math.log(3.0)))
        rho = q * math.exp(rng.uniform(math.log(1e-3), math.log(1e3)))

        log_lower = math.log1p((1.0 + s) * s * rho / q) / s
        log_upper = math.log(1.0 + s + (1.0 + s) * s * rho / q) / s

        def equation(log_r: float) -> float:
            r_inv = math.exp(-log_r)
            complement = ((1.0 - q) ** (1.0 + s)
                          * (1.0 - q * r_inv) ** (-s))
            return (q * math.exp(s * log_r) + complement - 1.0
                    - (1.0 + s) * s * rho)

        log_r = brentq(equation, 0.0, log_upper * (1.0 + 1e-12) + 1e-14)
        min_cr_lower_ratio = min(min_cr_lower_ratio, math.exp(log_r - log_lower))
        max_cr_upper_ratio = max(max_cr_upper_ratio, math.exp(log_r - log_upper))

    print(f"minimum CR root/lower-bound ratio: {min_cr_lower_ratio:.9f}")
    print(f"maximum CR root/upper-bound ratio: {max_cr_upper_ratio:.9f}")
    assert min_cr_lower_ratio >= 1.0 - 1e-9
    assert max_cr_upper_ratio <= 1.0 + 1e-9


if __name__ == "__main__":
    run()
