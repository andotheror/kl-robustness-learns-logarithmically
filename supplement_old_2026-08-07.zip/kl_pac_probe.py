import math

import numpy as np
from scipy.optimize import brentq


def binary_kl(q: float, p: float) -> float:
    if q == 0.0:
        return -math.log1p(-p)
    if q == 1.0:
        return -math.log(p)
    return q * math.log(q / p) + (1.0 - q) * math.log((1.0 - q) / (1.0 - p))


def inverse_nominal(q: float, rho: float) -> float:
    """Smallest nominal p whose KL-radius-rho inflation reaches q."""
    if rho == 0.0 or q == 0.0:
        return q
    if q == 1.0:
        return math.exp(-rho)
    # Solve in z=log(q/p), which remains well conditioned when p is exponentially small.
    def objective(z: float) -> float:
        log_p = math.log(q) - z
        p = 0.0 if log_p < -745.0 else math.exp(log_p)
        return q * z + (1.0 - q) * (math.log1p(-q) - math.log1p(-p)) - rho

    upper = (rho - (1.0 - q) * math.log1p(-q)) / q + 1.0
    z = brentq(objective, 0.0, upper, rtol=4.0 * np.finfo(float).eps, maxiter=100)
    log_p = math.log(q) - z
    return 0.0 if log_p < -745.0 else math.exp(log_p)


def localized_complexity(eps: float, rho: float, points: int = 4000):
    b = inverse_nominal(eps, rho)
    baseline = max(eps ** -2, b ** -1)

    # Resolve both the q approximately eps boundary and the rest of [0,1-eps].
    left = np.geomspace(max(eps * 1e-5, 1e-12), min(100 * eps, 1 - eps), points // 2)
    right_start = min(max(100 * eps, eps * 1e-5), 1 - eps)
    right = np.linspace(right_start, 1 - eps, points // 2)
    qs = np.unique(np.concatenate(([0.0], left, right)))

    best = (1.0 / b, 0.0)
    a = min(eps * eps, b)
    spacing_ratio = float("inf")
    for q in qs:
        p0 = inverse_nominal(float(q), rho)
        p1 = inverse_nominal(float(q + eps), rho)
        delta = p1 - p0
        spacing_ratio = min(spacing_ratio, delta / (a + math.sqrt(a * p0)))
        value = p0 / (delta * delta) + 1.0 / delta
        if value > best[0]:
            best = (value, float(q))
    return b, baseline, best, spacing_ratio


if __name__ == "__main__":
    print("eps rho inverse_scale baseline localized_max ratio argmax_q min_spacing_ratio")
    for eps in (0.1, 0.05, 0.02, 0.01, 0.005):
        for ratio in (0.0, 0.25, 1.0, 3.0, math.log(1 / eps), 10.0):
            rho = ratio * eps
            b, baseline, (maximum, qstar), spacing = localized_complexity(eps, rho)
            print(f"{eps:.4g} {rho:.4g} {b:.6g} {baseline:.6g} "
                  f"{maximum:.6g} {maximum / baseline:.4f} {qstar:.6g} {spacing:.4f}")
