"""Generate the exact binary-KL phase figure used in the paper."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def binary_kl(q: float, p: float) -> float:
    if q <= 0.0:
        return -np.log1p(-p)
    if q >= 1.0:
        return -np.log(p)
    return q * np.log(q / p) + (1.0 - q) * np.log((1.0 - q) / (1.0 - p))


def upper_event(p: float, rho: float) -> float:
    if rho == 0.0:
        return p
    if p >= np.exp(-rho):
        return 1.0
    lo, hi = p, 1.0
    for _ in range(90):
        mid = 0.5 * (lo + hi)
        if binary_kl(mid, p) <= rho:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def lower_inverse(q: float, rho: float) -> float:
    if rho == 0.0:
        return q
    lo, hi = np.finfo(float).tiny, q
    for _ in range(100):
        mid = np.sqrt(lo * hi)
        if binary_kl(q, mid) > rho:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


plt.rcParams.update(
    {
        "font.size": 8.5,
        "axes.labelsize": 8.5,
        "axes.titlesize": 9,
        "legend.fontsize": 7.3,
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "pdf.fonttype": 42,
    }
)

fig, axes = plt.subplots(1, 2, figsize=(6.65, 2.35))

m_grid = np.logspace(1, 12, 260)
for rho, color in [(0.0, "#555555"), (0.02, "#2878b5"), (0.1, "#d95f02"), (0.3, "#7b3294")]:
    curve = np.array([upper_event(1.0 / m, rho) for m in m_grid])
    label = rf"$\rho={rho:g}$"
    axes[0].loglog(m_grid, curve, color=color, lw=1.7, label=label)
axes[0].set_xlabel(r"effective samples $m$")
axes[0].set_ylabel(r"realizable robust error $\varepsilon$")
axes[0].set_title("Exact realizable learning curves")
axes[0].grid(True, which="both", alpha=0.2, lw=0.5)
axes[0].legend(frameon=False, loc="lower left")

eps_grid = np.logspace(-3, np.log10(0.3), 260)
for rho, color in [(0.01, "#1b9e77"), (0.03, "#2878b5"), (0.1, "#d95f02"), (0.2, "#7b3294")]:
    bvals = np.array([lower_inverse(eps, rho) for eps in eps_grid])
    ratio = np.maximum(1.0, eps_grid**2 / bvals)
    axes[1].loglog(eps_grid, ratio, color=color, lw=1.7, label=rf"$\rho={rho:g}$")
    idx = int(np.argmin(np.abs(np.log(np.maximum(eps_grid**2 / bvals, 1e-300)))))
    if 1 < idx < len(eps_grid) - 2:
        axes[1].scatter(eps_grid[idx], ratio[idx], s=13, color=color, zorder=3)
axes[1].axhline(1.0, color="#555555", lw=0.8, ls="--")
axes[1].set_ylim(0.8, 1e12)
axes[1].set_xlabel(r"target robust excess $\varepsilon$")
axes[1].set_ylabel("cost / classical cost")
axes[1].set_title("Agnostic rare-event amplification")
axes[1].grid(True, which="both", alpha=0.2, lw=0.5)
axes[1].legend(frameon=False, loc="upper right")

fig.tight_layout(w_pad=1.4)
fig.savefig(Path(__file__).with_name("kl_phase.pdf"), bbox_inches="tight")
